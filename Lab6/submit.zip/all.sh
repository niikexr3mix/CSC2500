#!/bin/bash

echo $0

echo $#

echo $*
